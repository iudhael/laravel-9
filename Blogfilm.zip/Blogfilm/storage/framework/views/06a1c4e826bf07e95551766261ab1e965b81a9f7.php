
<?php $__env->startSection('content'); ?>
    <div class="card">
        <header class="card-header">
            <p class="card-header-title">Titre : <?php echo e($film->title); ?></p>
        </header>
        <div class="card-content">
            <div class="content">
                <p>Année de sortie : <?php echo e($film->year); ?></p>
                <hr>
                <p><?php echo e($film->description); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blogfilm\resources\views/show.blade.php ENDPATH**/ ?>