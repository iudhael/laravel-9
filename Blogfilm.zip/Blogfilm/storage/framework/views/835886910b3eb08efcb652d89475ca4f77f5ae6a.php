
<?php $__env->startSection('css'); ?>
    <style>
        .card-footer {
        justify-content: center;
        align-items: center;
        padding: 0.4em;
        } .
            is-info {
        margin: 0.3em;
        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <?php if(session()->has('info')): ?>
        <div class="notification is-success">
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>

    <div class="card">
        <header class="card-header">
        <p class="card-header-title">Films</p>
        <a class="button is-info" href="<?php echo e(route('films.create')); ?>">Créer un film</a>
        </header>

        <div class="card-content">
            <div class="content">
                <table class="table is-hoverable">
                    <thead>
                        <tr>
                            
                            <th>Titre</th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td><strong><?php echo e($film->title); ?></strong></td>

                                <td><a class="button is-primary" href="<?php echo e(route('films.show', $film->id)); ?>">Voir</a></td>
                                
                                <td><a class="button is-warning" href="<?php echo e(route('films.edit', $film->id)); ?>">Modifier</a></td>
                                <td>
                                    <form action="<?php echo e(route('films.destroy', $film->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button
                                            class="button is-danger" type="submit">Supprimer
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        </div>
        <footer class="card-footer">
            <?php echo e($films->links()); ?>

        </footer>
      
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Blogfilm\resources\views/index.blade.php ENDPATH**/ ?>