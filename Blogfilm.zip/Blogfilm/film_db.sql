-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 07 sep. 2022 à 22:08
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `film_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `films`
--

CREATE TABLE `films` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` year(4) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `films`
--

INSERT INTO `films` (`id`, `title`, `year`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Fugiat laudantium aliquid.', 2018, 'Voluptate modi voluptates ut vitae eius ea. Labore dolor sed nisi molestiae totam. Adipisci et in nemo rerum cum ea.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(2, 'Ratione cum.', 1974, 'Autem fugit in magnam repellat deserunt quo. Est unde et sunt. Optio sed repellendus eos dolorum qui qui. Et dolore voluptas ipsum in quaerat sunt aperiam.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(3, 'Rem aut.', 1999, 'Nam rerum temporibus hic quia. Quis saepe harum asperiores illum sit facilis. Vel occaecati illo natus inventore commodi.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(4, 'Ea laboriosam.', 1996, 'Sit consequuntur dolor impedit harum ipsum molestiae. Sit ab sapiente inventore culpa. Vel nulla maiores enim eveniet pariatur illum. Et est eos vitae voluptatem sit et.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(5, 'Earum voluptates aut.', 1977, 'Totam possimus voluptatum alias. Amet quasi doloremque voluptas unde. Alias rerum facilis qui eveniet rerum occaecati. Rerum aut suscipit quod ea.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(6, 'Beatae voluptatem.', 2005, 'Ea dicta qui voluptatem fuga repellat sunt. Omnis adipisci numquam est possimus. Commodi dolore sint magni similique.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(7, 'Illum laborum.', 2018, 'Et maxime qui in illum corporis cupiditate labore. Est repudiandae est dignissimos expedita. Illum odio asperiores sed molestias natus praesentium.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(8, 'Illo odit.', 1992, 'Labore sint nobis et vero. Magni id aut voluptatem ad itaque perferendis animi. Libero accusamus quod dolores quia. Est et rerum eos quo molestiae. Sit eaque cumque iste voluptatem voluptatem.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(9, 'Voluptas nulla.', 2001, 'Laborum debitis quod fugit et dolorem quam quibusdam. Omnis adipisci est similique omnis sapiente aut. Et fugit quia nisi ex nisi.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(10, 'Odio reiciendis.', 1974, 'Doloribus accusantium autem dolor dolorem. Corporis veritatis maiores praesentium explicabo suscipit et modi. Et et quisquam consequatur fugit neque.', '2022-05-31 12:25:15', '2022-05-31 12:25:15'),
(11, 'Alce au pays des merveilles', 2002, 'reine des ❤', '2022-06-02 15:53:37', '2022-06-02 15:59:11');

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_05_28_094309_create_films_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Beth Heller', 'norval.kessler@example.org', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'rVhtpE1IDn', '2022-05-28 09:26:48', '2022-05-28 09:26:48'),
(2, 'Sunny Sporer', 'eparisian@example.net', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'P9fUCWT0cH', '2022-05-28 09:26:48', '2022-05-28 09:26:48'),
(3, 'Prof. Alvis Prohaska III', 'jeffry09@example.org', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'YJl32cjVEQ', '2022-05-28 09:26:48', '2022-05-28 09:26:48'),
(4, 'Rebeka Welch', 'white.daryl@example.org', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'EWQ774StS5', '2022-05-28 09:26:48', '2022-05-28 09:26:48'),
(5, 'Dr. Torrey Anderson', 'carolyne14@example.com', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'St8ZVJaAUG', '2022-05-28 09:26:48', '2022-05-28 09:26:48'),
(6, 'Cecilia Padberg', 'leannon.amy@example.org', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '3MtH6Trmav', '2022-05-28 09:26:49', '2022-05-28 09:26:49'),
(7, 'Ray Kuhlman', 'isabelle.jacobson@example.org', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'IRNAiquiKR', '2022-05-28 09:26:49', '2022-05-28 09:26:49'),
(8, 'Lenora Donnelly', 'annamarie21@example.org', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'YsCjx5bZVP', '2022-05-28 09:26:49', '2022-05-28 09:26:49'),
(9, 'Alexane Wuckert', 'huels.brandi@example.com', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'o84hKG6ZOG', '2022-05-28 09:26:49', '2022-05-28 09:26:49'),
(10, 'Saul Gulgowski', 'omer37@example.com', '2022-05-28 09:26:48', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ZOHCKuszEi', '2022-05-28 09:26:49', '2022-05-28 09:26:49'),
(11, 'Faye Sporer', 'conn.lamont@example.net', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '6SQ38e9GrI', '2022-05-31 12:23:37', '2022-05-31 12:23:37'),
(12, 'Stephania Schumm', 'yankunding@example.org', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'DkUlm4h4TK', '2022-05-31 12:23:38', '2022-05-31 12:23:38'),
(13, 'Annamae Bartoletti', 'akling@example.org', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'YdXqYi07NY', '2022-05-31 12:23:38', '2022-05-31 12:23:38'),
(14, 'Mr. Brycen Witting', 'braden01@example.net', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'lv1HB1fUqA', '2022-05-31 12:23:38', '2022-05-31 12:23:38'),
(15, 'Reanna Wisoky', 'stehr.gladys@example.com', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'AJddKrSfMD', '2022-05-31 12:23:38', '2022-05-31 12:23:38'),
(16, 'Adrienne Wiza', 'raoul.feeney@example.org', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'aIA0a11PP6', '2022-05-31 12:23:38', '2022-05-31 12:23:38'),
(17, 'Macy Frami', 'price.kiara@example.org', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'P1FvLH3LSK', '2022-05-31 12:23:38', '2022-05-31 12:23:38'),
(18, 'Marian Hessel', 'carter.efrain@example.org', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ltQ3G5fqRQ', '2022-05-31 12:23:38', '2022-05-31 12:23:38'),
(19, 'Prof. Guy Cremin DVM', 'wilma00@example.com', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'yQpuu7Ys9S', '2022-05-31 12:23:38', '2022-05-31 12:23:38'),
(20, 'Mathew Stanton', 'omurphy@example.com', '2022-05-31 12:23:37', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'rf6d27ybNV', '2022-05-31 12:23:38', '2022-05-31 12:23:38');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `films`
--
ALTER TABLE `films`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
