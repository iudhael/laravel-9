

<?php $__env->startSection('titre'); ?>
    Form
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>
    <form action="<?php echo e(url('users')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="nom">Entrez votre nom : </label>
        <input type="text" name="nom" id="nom">
        <input type="submit" value="Envoyer !">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Bloglaravel\resources\views/infos.blade.php ENDPATH**/ ?>