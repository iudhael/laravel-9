

<?php $__env->startSection('titre'); ?>
    Confirmations page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>
    <br>
    <div class="container">
        <div class="row card text-white bg-dark">
            <h4 class="card-header">Contactez-moi</h4>
            <div class="card-body">
                <p class="card-text">
                C'est bien enregistré ! Merci. Votre message a été transmis à
                    l'administrateur du site. Vous recevrez une réponse rapidement.
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Bloglaravel\resources\views/confirms.blade.php ENDPATH**/ ?>