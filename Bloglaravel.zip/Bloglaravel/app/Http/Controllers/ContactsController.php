<?php

namespace App\Http\Controllers;
use App\Http\Requests\ContactsRequest;

use Illuminate\Http\Request;


class ContactsController extends Controller
{
    public function create()
    {
        return view('contacts');
    } 

    public function store(ContactsRequest $request)
    {
        $contact = new \App\Models\Contact;
        $contact->email = $request->email;
        $contact->message = $request->message;
        $contact->save();
        return view('confirms');
    }
}
