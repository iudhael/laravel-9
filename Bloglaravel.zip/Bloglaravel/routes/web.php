<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\WelcomeController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\FactureController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\ContactsController;

Route::get('/', [WelcomeController::class, 'index']);

Route::get('article/{n}', [ArticleController::class, 'show'])->where('n', '[0-9]+');

Route::get('facture/{n}', [FactureController::class, 'show'])->where('n', '[0-9]+');

Route::get('users', [UsersController::class, 'create']);

Route::post('users', [UsersController::class, 'store']);

Route::get('contact', [ContactController::class, 'create']);

Route::post('contact', [ContactController::class, 'store']);


Route::get('contacts', [ContactsController::class, 'create'])->name('contacts.create');

Route::post('contacts', [ContactsController::class, 'store'])->name('contacts.store');


/*
Route::get('/', function () {
    return view('vue1');
});






Route::get('{n?}', function($n = 1) {
    return 'Je suis la page ' . $n . ' !';
    })->where('n', '[1-3]');


Route::get('article/{n}', function($n) {
    return view('article')->with('numero', $n);
    })->where('n', '[0-9]+');

Route::get('facture/{n}', function($n) {
    return view('facture')->with('numero', $n);
    })->where('n', '[0-9]+');

*/